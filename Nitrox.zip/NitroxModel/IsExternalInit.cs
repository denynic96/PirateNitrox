﻿// ReSharper disable once CheckNamespace

namespace System.Runtime.CompilerServices
{
    /// <summary>
    ///     Having this class allows us to use C# 9 record types.
    /// </summary>
    public class IsExternalInit
    {
    }
}
