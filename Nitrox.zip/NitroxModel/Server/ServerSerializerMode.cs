﻿namespace NitroxModel.Server
{
    public enum ServerSerializerMode
    {
        PROTOBUF,
        JSON
    }
}
