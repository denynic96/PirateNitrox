﻿namespace NitroxModel.Server
{
    public enum ServerGameMode
    {
        SURVIVAL = 0,
        FREEDOM = 2,
        HARDCORE = 257,
        CREATIVE = 1790,
    }
}
