﻿namespace NitroxModel.DataStructures.GameLogic
{
    public enum Perms
    {
        PLAYER,
        MODERATOR,
        ADMIN,
        CONSOLE
    }
}
