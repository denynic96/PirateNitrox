using System;

namespace NitroxModel.Packets
{
    [Serializable]
    public class RadioPlayPendingMessage : Packet
    {
    }
}
