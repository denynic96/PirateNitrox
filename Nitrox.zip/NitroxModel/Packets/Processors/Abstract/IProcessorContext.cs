﻿namespace NitroxModel.Packets.Processors.Abstract
{
    public interface IProcessorContext
    {
    }
}
