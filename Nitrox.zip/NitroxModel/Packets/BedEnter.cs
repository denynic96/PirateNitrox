﻿using System;

namespace NitroxModel.Packets
{
    [Serializable]
    public class BedEnter : Packet
    {
    }
}
