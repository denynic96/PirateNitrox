﻿namespace NitroxModel.MultiplayerSession
{
    public enum MultiplayerSessionAuthenticationAuthority
    {
        SERVER,
        OTHER //That which shall not be mentioned - yet...
    }
}
