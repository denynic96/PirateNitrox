﻿namespace NitroxPatcher.Patches
{
    public interface IPersistentPatch : INitroxPatch
    {
        
    }
}
