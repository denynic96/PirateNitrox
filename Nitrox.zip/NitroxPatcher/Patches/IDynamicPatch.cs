﻿namespace NitroxPatcher.Patches
{
    public interface IDynamicPatch : INitroxPatch
    {
        
    }
}
